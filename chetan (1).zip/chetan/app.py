import os
import numpy as np
import cv2
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, concatenate, BatchNormalization, Activation, Add, multiply

from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from flask import Flask, render_template, request, redirect, url_for, send_from_directory

# Helper functions
def conv_block(inputs, num_filters):
    x = Conv2D(num_filters, 3, padding="same")(inputs)
    x = BatchNormalization()(x)
    x = Activation("relu")(x)
    x = Conv2D(num_filters, 3, padding="same")(x)
    x = BatchNormalization()(x)
    x = Activation("relu")(x)
    return x

def nested_unet(input_shape):
    inputs = Input(input_shape)
    
    # Encoder
    c1 = conv_block(inputs, 64)
    p1 = MaxPooling2D((2, 2))(c1)

    c2 = conv_block(p1, 128)
    p2 = MaxPooling2D((2, 2))(c2)

    c3 = conv_block(p2, 256)
    p3 = MaxPooling2D((2, 2))(c3)

    c4 = conv_block(p3, 512)
    p4 = MaxPooling2D((2, 2))(c4)

    # Bottleneck
    c5 = conv_block(p4, 1024)

    # Decoder with nested skip connections
    u4 = UpSampling2D((2, 2))(c5)
    u4 = concatenate([u4, c4], axis=-1)
    u4 = conv_block(u4, 512)

    u3 = UpSampling2D((2, 2))(u4)
    u3 = concatenate([u3, c3], axis=-1)
    u3 = conv_block(u3, 256)

    u2 = UpSampling2D((2, 2))(u3)
    u2 = concatenate([u2, c2], axis=-1)
    u2 = conv_block(u2, 128)

    u1 = UpSampling2D((2, 2))(u2)
    u1 = concatenate([u1, c1], axis=-1)
    u1 = conv_block(u1, 64)

    outputs = Conv2D(1, 1, activation='sigmoid')(u1)

    model = Model(inputs, outputs)
    return model

def attention_block(g, x, num_filters):
    theta_x = Conv2D(num_filters, 1)(x)
    phi_g = Conv2D(num_filters, 1)(g)
    f = Activation("relu")(Add()([theta_x, phi_g]))
    psi_f = Conv2D(1, 1, activation='sigmoid')(f)
    return multiply([x, psi_f])

def attention_unet(input_shape):
    inputs = Input(input_shape)
    
    # Encoder
    c1 = conv_block(inputs, 64)
    p1 = MaxPooling2D((2, 2))(c1)

    c2 = conv_block(p1, 128)
    p2 = MaxPooling2D((2, 2))(c2)

    c3 = conv_block(p2, 256)
    p3 = MaxPooling2D((2, 2))(c3)

    c4 = conv_block(p3, 512)
    p4 = MaxPooling2D((2, 2))(c4)

    # Bottleneck
    c5 = conv_block(p4, 1024)

    # Decoder with attention mechanism
    g4 = UpSampling2D((2, 2))(c5)
    a4 = attention_block(g4, c4, 512)
    u4 = concatenate([g4, a4], axis=-1)
    u4 = conv_block(u4, 512)

    g3 = UpSampling2D((2, 2))(u4)
    a3 = attention_block(g3, c3, 256)
    u3 = concatenate([g3, a3], axis=-1)
    u3 = conv_block(u3, 256)

    g2 = UpSampling2D((2, 2))(u3)
    a2 = attention_block(g2, c2, 128)
    u2 = concatenate([g2, a2], axis=-1)
    u2 = conv_block(u2, 128)

    g1 = UpSampling2D((2, 2))(u2)
    a1 = attention_block(g1, c1, 64)
    u1 = concatenate([g1, a1], axis=-1)
    u1 = conv_block(u1, 64)

    outputs = Conv2D(1, 1, activation='sigmoid')(u1)

    model = Model(inputs, outputs)
    return model

# Flask web application
app = Flask(__name__)

UPLOAD_FOLDER = 'uploads/'
RESULT_FOLDER = 'results/'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER

# Load models
input_shape = (256, 256, 3)
nested_model = nested_unet(input_shape)
nested_model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])

attention_model = attention_unet(input_shape)
attention_model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    # Save file
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    # Load and preprocess image
    img = cv2.imread(file_path)
    img = cv2.resize(img, (256, 256))
    img = np.expand_dims(img, axis=0) / 255.0

    # Segment using both models
    nested_prediction = nested_model.predict(img)[0]
    attention_prediction = attention_model.predict(img)[0]

    # Convert predictions to binary images
    nested_segmentation = (nested_prediction > 0.5).astype(np.uint8) * 255
    attention_segmentation = (attention_prediction > 0.5).astype(np.uint8) * 255

    # Save results
    nested_result_path = os.path.join(app.config['RESULT_FOLDER'], 'nested_' + file.filename)
    attention_result_path = os.path.join(app.config['RESULT_FOLDER'], 'attention_' + file.filename)
    cv2.imwrite(nested_result_path, nested_segmentation)
    cv2.imwrite(attention_result_path, attention_segmentation)

    return redirect(url_for('display_results', filename=file.filename))

@app.route('/results/<filename>')
def display_results(filename):
    nested_result = url_for('static', filename='results/nested_' + filename)
    attention_result = url_for('static', filename='results/attention_' + filename)
    return render_template('results.html', nested_result=nested_result, attention_result=attention_result)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['RESULT_FOLDER'], exist_ok=True)
    app.run(debug=True)